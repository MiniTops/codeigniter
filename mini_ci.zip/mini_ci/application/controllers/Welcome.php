<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __Construct()
	{
		parent::__construct();
		$this->load->Model('Model');
	}
	public function index()
	{
		$this->load->view('welcome_message');
	}
	public function mini()
	{
		$data['city']=$this->Model->select_all("city");
		//print_r($data['city']);
		$this->load->view('reg',$data);
	}
	public function insert()
	{
		$fname=$this->input->post('fname');
		$email=$this->input->post('email');
		$password=md5($this->input->post('password'));
		$city=$this->input->post('city_fk');
		$gender=$this->input->post('gender');
		$hby=implode(',',$this->input->post('hby'));


		 // image uploading
                $config['upload_path']          = './uploads/';
                $config['allowed_types']        = 'gif|jpg|png';
              //  $config['max_size']             = 100;
               // $config['max_width']            = 1024;
               // $config['max_height']           = 768;
                 $this->load->library('upload', $config);

                 if ( ! $this->upload->do_upload('image'))
                {
                        echo"error";
                }
                else
                {
                        //$data = array('upload_data' => $this->upload->data());
                	$upload_data=$this->upload->data();
                        $image=$upload_data['file_name'];

                      //  $this->load->view('upload_success', $data);
                }

                

		$data=array("fname"=>$fname,"email"=>$email,"password"=>$password,"city_fk"=>$city,"gender"=>$gender,"hobbies"=>$hby,"image"=>$image);
		$insert_data = $this->Model->insert_data("user",$data);
		if ($insert_data) {
			redirect('Welcome/mini');
		}
		else
		{
			echo "error";
		}
	}
	public function showdata()
	{
		//$data['user_data'] = $this->Model->select_all("user");
		$data['user_data'] = $this->Model->join_two("user","city","`user`.`city_fk`=`city`.`c_id`");
		//print_r($data['user_data']);
		$this->load->view('showdata',$data);
	}
	public function delete($id)
{
	$where=array("user_id"=>$id);
	$delete=$this->Model->delete("user",$where);
	if($delete)
	{
		redirect('Welcome/showdata');
	}
	else
	{
		echo"error";
	}

}
public function edit($id)
{  
    $where=array("user_id"=>$id);  
	$data['edit_data']=$this->Model->select_where("user",$where);
	$data['city']=$this->Model->select_all("city");
	$this->load->view('edit',$data);
}
public function update()
{
	$id=$this->input->post('user_id');
	$fname=$this->input->post('fname');
	$email=$this->input->post('email');
	$password=md5($this->input->post('password'));
	$city=$this->input->post('city');
	$gender=$this->input->post('gender');
	$hby=implode(',',$this->input->post('hby'));
	if($_FILES['image']['name'])
	{
		$config['upload_path']          = './uploads/';
        $config['allowed_types']        = 'gif|jpg|png';
        $this->load->library('upload', $config);
         if ( ! $this->upload->do_upload('image'))
                {
                        echo"error";
                }
                else
                {
                        
                	$upload_data=$this->upload->data();
                        $image=$upload_data['file_name'];

                      
                }



	}
	else
	{
		$image=$this->input->post('old_image');
	}
	$where=array("user_id"=>$id);
	$data=array("fname"=>$fname,"email"=>$email,"password"=>$password,"city_fk"=>$city,"gender"=>$gender,"hobbies"=>$hby,"image"=>$image);
	$update=$this->Model->update("user",$data,$where);
	if($update)
	{
		redirect('Welcome/showdata');
	}
	else
	{
		echo"error";
	}
}
public function login()
{
	$this->load->view('login');
}
public function auth()
{
	$email=$this->input->post('email');
	$password=md5($this->input->post('password'));
	$where=array("email"=>$email,"password"=>$password);
	$login=$this->Model->select_where("user",$where);
	//print_r($login);
	if(count($login)==1)
	{
		echo"login";
		$sess_array=array();
		foreach ($login as $key => $value) {
			$sess_array=array("user_id"=>$value->user_id,
				"fname"=>$value->fname,
			"email"=>$value->email,
		"password"=>$value->password);
			$this->session->set_userdata($sess_array);
			//echo $this->session->userdata('email');
			redirect('welcome/profile');
		}
	}
	else
	{
		echo"check username and password";
	}

}
public function profile()
{
	if(empty($this->session->userdata('email')))
	{
		redirect('welcome/login');
	}
	else
	{

   $this->load->view('profile');

	}
	
}
public function logout()
{
	session_destroy();
	redirect('welcome/login');
}

	
	

	
}
