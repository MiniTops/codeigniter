<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cart extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __Construct()
	{
		parent::__construct();
		$this->load->Model('Model');
	}
	public function mini()
	{

	
		$this->load->view('category');
	}
	
	public function insert()
	{
		$catname=$this->input->post('c_name');
		$data=array("c_name"=>$catname);
		
		
		$ins = $this->Model->insert_data("category",$data);
		if($ins)
		{
			redirect('Cart/mini');
		}
		else
		{
			echo "error";
		}
	}
	public function rahul()
	{

	$data['category']=$this->Model->select_all("category");
	//print_r($data['category']);
		$this->load->view('subcategory',$data);

	}
	public function subcategoryadd()
	{
		$subcat_name=$this->input->post('subcat_name');
		$category=$this->input->post(c_fk);
		$data=array("subcat_name"=>$subcat_name,"c_fk"=>$category);

		$ins = $this->Model->insert_data("subcategory",$data);
		if($ins)
		{
			redirect('Cart/rahul');
		}
		else
		{
			echo "error";
		}
		
		
	}
	public function sonu()
	{
		$data['category']=$this->Model->select_all("category");
		$data['subcategory']=$this->Model->select_all("subcategory");

		$this->load->view('product',$data);
	}
	public function addproduct()
	{    
		$category=$this->input->post('category');
		$subcategory=$this->input->post('subcategory');

		$p_name=$this->input->post('p_name');
		$p_details=$this->input->post('p_details');
		$p_price=$this->input->post('p_price');
		// image uploading
                $config['upload_path']          = './uploads/';
                $config['allowed_types']        = 'gif|jpg|png';
              //  $config['max_size']             = 100;
               // $config['max_width']            = 1024;
               // $config['max_height']           = 768;
                 $this->load->library('upload', $config);

                 if ( ! $this->upload->do_upload('p_image'))
                {
                        echo"error";
                }
                else
                {
                        //$data = array('upload_data' => $this->upload->data());
                	$upload_data=$this->upload->data();
                        $p_image=$upload_data['file_name'];

                      //  $this->load->view('upload_success', $data);
                }
                $data=array("c_fk"=>$category,"sub_fk"=>$subcategory,"p_name"=>$p_name,"p_details"=>$p_details,"p_price"=>$p_price,"p_image"=>$p_image);
                	$ins = $this->Model->insert_data("product",$data);
		if($ins)
		{
			redirect('Cart/sonu');
		}
		else
		{
			echo "error";
		}


	}
	public function showproduct()
	{
		$data['user_data'] = $this->Model->join_three("product","category","subcategory","`product`.`c_fk`=`category`.`c_id`","`product`.`sub_fk`=`subcategory`.`subcat_id`");
		$this->load->view('showproduct',$data);
	}
	public function delete($id)
{
	
	$where=array("p_id"=>$id);
	$delete=$this->Model->delete("product",$where);
	if($delete)
	{
		redirect('Cart/showproduct');
	}
	else
	{
		echo"error";
	}
	
}
public function edit($id)
{  
    $where=array("p_id"=>$id);  
	$data['productedit_data']=$this->Model->select_where("product",$where);
	$data['category']=$this->Model->select_all("category");
	$data['subcategory']=$this->Model->select_all("subcategory");

	$this->load->view('productedit',$data);
}
public function update()
{
	$p_id=$this->input->post('p_id');
	$p_name=$this->input->post('p_name');
	$p_details=$this->input->post('p_details');
	$p_price=$this->input->post('p_price');
	$category=$this->input->post('category');
	$subcategory=$this->input->post('subcategory');
	if($_FILES['p_image']['name'])
	{
		$config['upload_path']          = './uploads/';
        $config['allowed_types']        = 'gif|jpg|png';
        $this->load->library('upload', $config);
         if ( ! $this->upload->do_upload('p_image'))
                {
                        echo"error";
                }
                else
                {
                        
                	$upload_data=$this->upload->data();
                        $image=$upload_data['file_name'];

                      
                }



	}
	else
	{
		$image=$this->input->post('old_image');
	}
	$where=array("p_id"=>$p_id);
	$data=array("p_name"=>$p_name,"p_details"=>$p_name,"p_price"=>$p_price,"c_fk"=>$category,"sub_fk"=>$subcategory,"p_image"=>$image);
	$update=$this->Model->update("product",$data,$where);
	if($update)
	{
		redirect('Cart/showproduct');
	}
	else
	{
		echo"error";
	}
}
public function user_product()
{
	$data['all_product']=$this->Model->select_all('product');
	$this->load->view('user_product',$data);
}
public function product_details($id)
{
	$where=array("p_id"=>$id);
	$data['product_details']=$this->Model->select_where("product",$where);
	$this->load->view('product_details',$data);

}


}


	
	
	
	
	

