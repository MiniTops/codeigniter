<html>
<head>
	<title></title>
</head>
<body>
	<form method="POST"   action="<?php echo base_url()?>Cart/insert">
	
	<label>category name</label>
	<input type="text" name="c_name"><br>
	<input type="submit" name="submit" value="reg">
</form>
</body>
</html>

