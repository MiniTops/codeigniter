<?php
echo $this->session->userdata('user_id')."<br>";
echo $this->session->userdata('fname')."<br>";
echo $this->session->userdata('email')."<br>";
echo $this->session->userdata('password')."<br>";

?>
<a href='<?php echo base_url()?>/welcome/logout'>logout</a>