<!DOCTYPE html>
<html>
<head>
	<title>Form</title>
</head>
<body>
	<h1 align="center"><u><strong>Admin Login</strong></u> </h1>
	<form method="POST">
	<table border="2" cellspacing="10" cellpadding="10" align="center">
		<tr>
		<th>FirstName</th>
		<th><input type="text" name="fname" placeholder="Enter the FirstName"></th>
		</tr>
		<tr>
		<th>Email</th>
		<th><input type="text" name="email" placeholder="Enter the Email"></th>
		</tr>
		<tr>
		<th>Password</th>
		<th><input type="password" name="password" placeholder="Enter the Password"></th>
		</tr>
		<tr>

		<th colspan="2"  align="center"><input type="submit" name="Login" value="Login"></th>
		</tr>
	
	</table>
	</form>
</body>
</html>