<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form method="POST"  enctype="multipart/form-data" action="<?php echo base_url()?>welcome/insert">
	<label>fname</label>
	<input type="text" name="fname"><br>
	<label>email</label>
	<input type="email" name="email"><br>
	<label>password</label>
	<input type="password" name="password"><br>


	<select name="city_fk">
		<option><--select city--></option>
			<?php
				foreach ($city as $key => $value) { ?>
					<option value="<?php echo $value->c_id;?>"><?php echo $value->c_name;?></option>
				<?php }
			?>
			
		
	</select><br>
	<label>gender</label>
	<input type="radio" name="gender" value="male">Male 
	<input type="radio" name="gender" value="female">Female<br>
	<label>hobbies</label>
	<input type="checkbox" name="hby[]" value="java">Java
	<input type="checkbox" name="hby[]" value="php">PHP
	<input type="checkbox" name="hby[]" value="python">PHYTHON<br>
	<input type="file" name="image"><br>


<input type="submit" name="submit" value="submit">


</form>
</body>
</html>