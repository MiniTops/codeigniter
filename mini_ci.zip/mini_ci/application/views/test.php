<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
</head>
<body>
<h1> Hello Mini Yadav Welcome To Codeigiter!</h1>
</body>
</html>