<?php

//print_r($edit_data);

 foreach ($edit_data as $key => $value) {
	?>


<form method="POST" enctype="multipart/form-data" action="<?php echo base_url()?>welcome/update">
	<label>user_id</label>
	<input type="text" name="user_id"  readonly value="<?php echo $value->user_id?>"><br>
	<label>fname</label>
	<input type="text" name="fname" value="<?php echo $value->fname?>"><br>
	<label>email</label>
	<input type="text" name="email" value="<?php echo $value->email?>"><br>
	<label>password</label>
	<input type="text" name="password" value="<?php echo $value->password?>"><br>
	<select name="city">
		<?php foreach ($city as $k => $v) 
		{
			?>


		
		<option <?php if($v->c_id==$value->city_fk){ echo "selected"; } ?>
			value="<?php echo $v->c_id?>"><?php echo $v->c_name?>
			
		</option>
		<?php } ?>
		
	</select><br>
	<label>gender</label>
	<input type="radio" name="gender" <?php if($value->gender =="male"){ echo "checked"; }?> value="male">Male
	<input type="radio" name="gender" <?php if($value->gender =="female"){ echo "checked"; } ?> value="female">Female<br>
	<label>hobbies</label>
	<?php $gg=explode(',',$value->hobbies);


	//print_r($gg);
	?>
	<input type="checkbox" name="hby[]" <?php if(in_array("java",$gg)) {echo "checked";}?> value="java">JAVA
	<input type="checkbox" name="hby[]" <?php if(in_array("php",$gg)) { echo "checked";} ?> value="php">PHP
	<input type="checkbox" name="hby[]" <?php if(in_array("python", $gg)) { echo "checked";} ?> value="python">PYTHON <br>
	<label>current image</label>
	<img src="<?php echo base_url()?>uploads/<?php echo $value->image;?>" height="200px" width="200px">
	<input type="text" readonly name="old_image" value="<?php echo $value->image ?>"><br>
	<label>choose image</label>
	<input type="file" name="image">





<input type="submit" name="updata" value="update">

</form>
<?php } ?>



