
<?php foreach ($productedit_data as $key=>$value){
	?>
<form method="POST" enctype="multipart/form-data" action="<?php echo base_url()?>Cart/update">
	<label>p_id</label>
	<input type="text" name="p_id" readonly value="<?php echo $value->p_id?>"><br>
	<label>p_name</label>
	<input type="text" name="p_name" value="<?php echo $value->p_name?>"><br>
	<label>p_details</label>
	<textarea name="p_details"  rows="10" cols="100" >
		<?php echo $value->p_details?>
</textarea>
 <br>
	<label>p_price</label>
	<input type="text" name="p_price" value="<?php echo $value->p_price?>"><br>
	<label>current image</label>
	<img src="<?php echo base_url()?>uploads/<?php echo $value->p_image;?>" height="200px" width="200px">
	<input type="text" name="old_image" value="<?php echo $value->p_image?>"><br>
	<label>choose image</label>
	<input type="file" name="p_image"><br>
	<label>category</label>


					<select name="category">
						
			<?php foreach($category as $k=>$v){
			?>
			<option <?php if($v->c_id==$value->c_fk){ echo "selected";}?> value="<?php echo $v->c_id?>"><?php echo $v->c_name?>
				
			</option>
			<?php } ?>
						</select>
						<br>
						<label>subcategory</label>
					
					
						<select name="subcategory">
					
			<?php foreach($subcategory as $ka=>$va){
			?>
			<option <?php if($va->subcat_id==$value->sub_fk){ echo "selected";}?> value="<?php echo $va->subcat_id?>"><?php echo $va->subcat_name?>
				
			</option>
			<?php } ?>
						</select>
						<br>
					
					<input type="submit" name="update" value="update">
				
						

			
		</form>
		<?php } ?>
	
</head>