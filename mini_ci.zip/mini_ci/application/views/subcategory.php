<html>
<head>
	<title></title>
</head>
<body>
	<form method="POST"   action="<?php echo base_url()?>Cart/subcategoryadd">
	
	<label>subcategory name</label>
	<input type="text" name="subcat_name"><br>
	   <select name="c_fk">
		<option><--select category--></option>
			<?php foreach($category as $key=>$value){
			?>
			<option value="<?php echo $value->c_id?>"><?php echo $value->c_name?>
				
			</option>
			<?php } ?>
		</select>

	<input type="submit" name="submit" value="reg">
</form>
</body>
</html>

