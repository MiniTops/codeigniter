	<table border="2">
	<tr>
		<th>p_id</th>
		<th>p_image</th>
		<th>p_name</th>
		<th>p_details</th>
		<th>p_price</th>
		<th>category</th>
		<th>subcategory</th>
		
		<th colspan="2" >Action</th>

	</tr>
	<?php foreach ($user_data as $key => $value) {
		?>
		<tr>
			<td><?php echo $value->p_id;?></td>
			<td><img src="<?php echo base_url()?>uploads/<?php echo $value->p_image;?>" height="200px" width="200px">
			<td><?php echo $value->p_name;?></td>
			<td><?php echo $value->p_details;?></td>
			<td><?php echo $value->p_price;?></td>
			<td><?php echo $value->c_name;?></td>
			<td><?php echo $value->subcat_name;?></td>
			

			<td><a href="<?php echo base_url()?>Cart/delete/<?php echo $value->p_id;?>">DELETE</a></td>
			<td><a href="<?php echo base_url()?>Cart/edit/<?php echo $value->p_id;?>">EDIT</a></td>
			
			

			



		</tr>

<?php } ?>
	



	
</table>