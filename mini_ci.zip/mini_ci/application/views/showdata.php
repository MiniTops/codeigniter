<table border="2">
	<tr>
		<th>user_id</th>
		<th>image</th>
		<th>fname</th>
		<th>email</th>
		<th>password</th>
		<th>city</th>
		<th>gender</th>
		<th>hobbies</th>
		<th colspan="2" >Action</th>

	</tr>
	<?php foreach ($user_data as $key => $value) {
		?>
		<tr>
			<td><?php echo $value->user_id;?></td>
			<td><img src="<?php echo base_url()?>uploads/<?php echo $value->image;?>" height="200px" width="200px">
			<td><?php echo $value->fname;?></td>
			<td><?php echo $value->email;?></td>
			<td><?php echo $value->password;?></td>
			<td><?php echo $value->c_name;?></td>
			<td><?php echo $value->gender;?></td>
			<td><?php echo $value->hobbies;?></td>

			<td><a href="<?php echo base_url()?>Welcome/delete/<?php echo $value->user_id;?>">DELETE</a></td>
			<td><a href="<?php echo base_url()?>Welcome/edit/<?php echo $value->user_id;?>">EDIT</a></td>
			
			

			



		</tr>

<?php } ?>
	



	
</table>