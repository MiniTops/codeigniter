<form method="POST" action="<?php echo base_url()?>welcome/auth">
	<input type="text" name="email" placeholder="Enter email"><br>
	<input type="text" name="password" placeholder="Enter password"><br>
	<input type="submit" name="submit" value="login">
	
	
</form>