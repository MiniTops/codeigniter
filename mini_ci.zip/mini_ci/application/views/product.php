<html>
<head>
	<body>
		<form method="POST"  enctype="multipart/form-data" action="<?php echo base_url()?>Cart/addproduct">
			<table align="center" border="1">
				<tr>
					<th>select category</th>
					<td>
						<select name="category">
							<option><--select category--></option>
			<?php foreach($category as $key=>$value){
			?>
			<option value="<?php echo $value->c_id?>"><?php echo $value->c_name?>
				
			</option>
			<?php } ?>
						</select>
					</td>
				</tr>
				<tr>
					<th>select subcategory</th>
					<td>
						<select name="subcategory">
							<option><--select subcategory--></option>
			<?php foreach($subcategory as $key=>$value){
			?>
			<option value="<?php echo $value->subcat_id?>"><?php echo $value->subcat_name?>
				
			</option>
			<?php } ?>
						</select>
					</td>
					<tr>
						<th>add product</th>
						<td>
							<input type="text" name="p_name">
						</td>
					</tr>
					<tr>
						<th>product details</th>
						<td>
					<textarea name="p_details" rows="10" cols="50">
						
					</textarea>
						</td>
					</tr>
					<tr>
						<th>product price</th>
						<td>
							<input type="text" name="p_price">
						</td>
					</tr>
				<tr>
						<th>product image</th>
						<td>
							<input type="file" name="p_image">
						</td>
					</tr>
					<td><input type="submit" name="submit" value="reg">
			</table>

			
		</form>
	
</head>